package messenger;

import javax.swing.JTextField;

public class ReadThread implements Runnable
{
	private Thread thr;
	private NetworkUtil nc;
	public String t;

	public ReadThread(NetworkUtil nc) 
	{
		this.nc = nc;
		this.thr = new Thread(this);
		thr.start();
	}
	
	public void run() 
	{
            serverinterface si=new serverinterface();
            clientinterface ci=new clientinterface();

		try
		{
                    //   instance i
			while(true)
			{
			        
				
                            
                            t=nc.read().toString();
                                   if(!t.isEmpty())
                                   {
                                        nc.c.jTextArea1.append(t);
                                        nc.s.jTextArea1.append(t);

                                   }
//                                   ci.getmessage(t);
//                                   si.getmessage(t);
//                                   si.jTextArea1.setText(t);
//                                   si.jTextArea1.getText();
//                                   ci.jTextArea1.getText();
                                   //System.out.println(t);
                                       //se.jTextArea1

			}
		}catch(Exception e)
		{
			System.out.println (e);                        
		}			
                nc.closeConnection();
		
	}
}



